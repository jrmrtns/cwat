﻿using $safeprojectname$.Splash;
using $saferootprojectname$.Common.Constants;
using System;
using System.Windows;
using SplashScreen = $safeprojectname$.Views.SplashScreen;

namespace $safeprojectname$
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App
    {
        /// <summary>
        ///
        /// </summary>
        [STAThread()]
        private static void Main(string[] args)
        {
            SplashScreenHelper.Splash = new SplashScreen();
            SplashScreenHelper.ShowSplash();

            App app = new App();
            app.InitializeComponent();

            if (args != null && args.Length > 0)
            {
                Constants.OnBehalfUser = args[0];
            }

            app.Run();
        }

        /// <summary>
        /// Programmstart
        /// </summary>
        /// <param name="e"></param>
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            Bootstrapper bootstrapper = new Bootstrapper();
            bootstrapper.Run();
        }
    }
}