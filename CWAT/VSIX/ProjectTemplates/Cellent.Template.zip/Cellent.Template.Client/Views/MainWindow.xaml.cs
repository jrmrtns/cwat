﻿namespace $safeprojectname$.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow
    {
        /// <summary>
        /// Erstellt eine neue Instanz des Hauptfensters
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}