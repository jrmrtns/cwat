﻿using $saferootprojectname$.Domain.Core.Interfaces.Entities;

namespace $safeprojectname$.Entities
{
    partial class ChangeLog
    {
        /// <summary>
        /// Gets or sets the domain object.
        /// </summary>
        /// <value>
        /// The domain object.
        /// </value>
        public IDomainObject DomainObject { get; set; }
    }
}