﻿using $saferootprojectname$.Domain.Core;
using $saferootprojectname$.Domain.Core.Entities;
using $saferootprojectname$.Domain.Core.Interfaces.Entities;
using $saferootprojectname$.Domain.Core.Interfaces.Factories;
using $saferootprojectname$.Domain.Core.Interfaces.Mapper;
using System;

namespace $safeprojectname$.DaoMapper
{
    partial class ChangeLogMapper
    {
        private readonly IGenericDaoMapper<IDomainObject, DomainObjectDao> _domainObjectMapper;

        /// <summary>
        /// Initializes a new instance of the <see cref="ChangeLogMapper"/> class.
        /// </summary>
        /// <param name="factory">The factory.</param>
        /// <param name="domainObjectMapper">The domain object mapper.</param>
        public ChangeLogMapper(Lazy<IDomainFactory<IChangeLog>> factory, GenericDaoMapper<IDomainObject, DomainObjectDao> domainObjectMapper) : this(factory)
        {
            _domainObjectMapper = domainObjectMapper;
        }

        partial void OnConvertAdditionalFields(IChangeLog source, ChangeLogDao dest)
        {
            dest.DomainObject = _domainObjectMapper.Convert(source.DomainObject);
        }

        partial void OnConvertAdditionalFields(ChangeLogDao source, IChangeLog dest)
        {
            dest.DomainObject = _domainObjectMapper.Convert(source.DomainObject);
        }
    }
}