﻿namespace $safeprojectname$.Views
{
    /// <summary>
    /// Interaction logic for CreateUserView.xaml
    /// </summary>
    public partial class CreateResourceView
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreateResourceView"/> class.
        /// </summary>
        public CreateResourceView()
        {
            InitializeComponent();
        }
    }
}