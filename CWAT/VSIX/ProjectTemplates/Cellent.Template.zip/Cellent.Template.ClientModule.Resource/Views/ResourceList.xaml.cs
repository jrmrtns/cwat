﻿namespace $safeprojectname$.Views
{
    /// <summary>
    /// Interaction logic for ResourceList.xaml
    /// </summary>
    public partial class ResourceList
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ResourceList"/> class.
        /// </summary>
        public ResourceList()
        {
            InitializeComponent();
        }
    }
}