﻿using $saferootprojectname$.Client.Core.Interfaces.Models;
using $saferootprojectname$.Client.Core.ServiceClient;
using $saferootprojectname$.Common.Constants;
using $saferootprojectname$.Common.DataTransferObjects;
using $saferootprojectname$.Common.Exceptions;
using $saferootprojectname$.Common.Interfaces.WCFServices;
using $saferootprojectname$.Common.Validation;
using System.Threading.Tasks;

namespace $safeprojectname$.Models
{
    public partial class ResourceModel
    {
        /// <summary>
        /// Saves the Resource asynchronous.
        /// </summary>
        /// <returns></returns>
        /// <exception cref="$saferootprojectname$.Common.Exceptions.ValidationException"></exception>
        public async Task<IResourceModel> SaveAsync()
        {
            if (State == Constants.EntityState.Unchanged)
                return this;

            ValidationSummary summary = Validator.Validate(this);
            if (!summary.IsValid)
                throw new ValidationException(summary);

            ResourceDto resource = await ServiceClient<IResourceService>
                .ExecuteAsync(d => d.SaveAsync(Factory.Convert(this)));

            IResourceModel resourceModel = Factory.Convert(resource);
            return resourceModel;
        }
    }
}