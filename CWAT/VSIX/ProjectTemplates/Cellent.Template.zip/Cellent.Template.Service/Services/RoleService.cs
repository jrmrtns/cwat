﻿using $saferootprojectname$.Common.DataTransferObjects;
using $saferootprojectname$.Common.Interceptors;
using $saferootprojectname$.Common.Interfaces.WCFServices;
using $saferootprojectname$.Domain.Core.Implementations;
using $saferootprojectname$.Domain.Core.Interfaces.Factories;
using $saferootprojectname$.Domain.Interfaces.Entities;
using System.Collections.Generic;
using System.ServiceModel;
using System.Threading.Tasks;

namespace $safeprojectname$.Services
{
    /// <summary>
    /// Implementation for MasterDataService
    /// </summary>
    [Log]
    public class RoleService : IRoleService
    {
        private readonly IDomainFactory<IRole> _roleFactory;
        private readonly GenericDomainMapper<IRole, RoleDto> _roleMapper;

        /// <summary>
        /// Initializes a new instance of the <see cref="RoleService" /> class.
        /// </summary>
        /// <param name="roleMapper">The role mapper.</param>
        /// <param name="roleFactory">The role factory.</param>
        public RoleService(GenericDomainMapper<IRole, RoleDto> roleMapper, IDomainFactory<IRole> roleFactory)
        {
            _roleMapper = roleMapper;
            _roleFactory = roleFactory;
        }

        /// <summary>
        /// Finds the roles asynchronous.
        /// </summary>
        /// <returns>IEnumerable of the RoleDto</returns>
        [OperationBehavior(Impersonation = ImpersonationOption.Allowed)]
        public async Task<IEnumerable<RoleDto>> FindRolesAsync()
        {
            IRole role = _roleFactory.Create();
            return _roleMapper.Convert(await role.FindAllWithChildrenAsync());
        }

        /// <summary>
        /// Saves the role asynchronous.
        /// </summary>
        /// <param name="roleDto">The role.</param>
        /// <returns></returns>
        public async Task<RoleDto> SaveRoleAsync(RoleDto roleDto)
        {
            IRole role = _roleMapper.Convert(roleDto);
            return _roleMapper.Convert(await role.SaveOrUpdateAsync(role));
        }
    }
}