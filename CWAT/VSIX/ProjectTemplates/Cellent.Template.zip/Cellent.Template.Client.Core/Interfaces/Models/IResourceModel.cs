﻿using System.Threading.Tasks;

namespace $safeprojectname$.Interfaces.Models
{
    /// <summary>
    /// Interface für User
    /// </summary>
    public partial interface IResourceModel
    {
        /// <summary>
        /// Saves this instance.
        /// </summary>
        Task<IResourceModel> SaveAsync();
    }
}
