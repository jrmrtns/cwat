﻿using System;
using Prism.Events;

namespace $safeprojectname$.Events
{
    /// <summary>
    /// wird gesendet, wenn der User informiert werden soll
    /// </summary>
    public class NotifyUserPubSubEvent : PubSubEvent<Exception>
    {
    }
}
