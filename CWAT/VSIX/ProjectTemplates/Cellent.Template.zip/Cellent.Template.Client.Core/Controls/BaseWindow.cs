﻿using $safeprojectname$.Commands;
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace $safeprojectname$.Controls
{
    /// <summary>
    /// Basisklasse für Windows mit "Stil"
    /// </summary>
    public class BaseWindow : Window
    {
        #region Fields

        private HwndSource _hwndSource;
        private Point _startPoint;

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="BaseWindow"/> class.
        /// </summary>
        public BaseWindow()
        {
            SetResourceReference(StyleProperty, "MessageBox");
            Closing += BaseWindow_Closing;
            PreviewMouseMove += OnPreviewMouseMove;
            SourceInitialized += BaseWindow_SourceInitialized;
        }

        #endregion Constructors

        #region Enums

        private enum ResizeDirection
        {
            Left = 1,
            Right = 2,
            Top = 3,
            TopLeft = 4,
            TopRight = 5,
            Bottom = 6,
            BottomLeft = 7,
            BottomRight = 8,
        }

        #endregion Enums

        #region Methods

        /// <summary>
        /// When overridden in a derived class, is invoked whenever application code or internal processes call <see cref="M:System.Windows.FrameworkElement.ApplyTemplate" />.
        /// </summary>
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            InputBindings.Add(new KeyBinding(new CellentCommand(() =>
            {
                TextBox txt = GetTemplateChild("PART_SEARCH") as TextBox;
                if (txt != null)
                    txt.Focus();
            }), Key.F, ModifierKeys.Control));

            Border title = GetTemplateChild("PART_TITLEBAR") as Border;
            Button closeButton = GetTemplateChild("PART_CLOSE") as Button;
            Button maximizeButton = GetTemplateChild("PART_MAXIMIZE_RESTORE") as Button;
            Button minimizeButton = GetTemplateChild("PART_MINIMIZE") as Button;

            if (title != null) title.MouseLeftButtonDown += title_MouseLeftButtonDown;
            if (title != null) title.MouseMove += title_MouseMove;
            if (closeButton != null) closeButton.Click += CloseButton_Click;
            if (maximizeButton != null) maximizeButton.Click += maximizeButton_Click;
            if (minimizeButton != null) minimizeButton.Click += minimizeButton_Click;

            Grid resizeGrid = GetTemplateChild("resizeGrid") as Grid;
            if (resizeGrid != null)
            {
                foreach (UIElement element in resizeGrid.Children)
                {
                    Rectangle resizeRectangle = element as Rectangle;
                    if (resizeRectangle != null)
                    {
                        resizeRectangle.PreviewMouseDown += ResizeRectangle_PreviewMouseDown;
                        resizeRectangle.MouseMove += ResizeRectangle_MouseMove;
                    }
                }
            }
        }

        internal void title_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            _startPoint = PointToScreen(Mouse.GetPosition(this));

            if (e.ClickCount == 2)
            {
                WindowState = WindowState == WindowState.Normal ? WindowState.Maximized : WindowState.Normal;
            }
            DragMove();
        }

        /// <summary>
        /// Close event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected virtual void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        /// <summary>
        /// OnInitialized
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInitialized(EventArgs e)
        {
            SourceInitialized += OnSourceInitialized;
            base.OnInitialized(e);
        }

        /// <summary>
        /// OnPreviewMouseMove
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void OnPreviewMouseMove(object sender, MouseEventArgs e)
        {
            if (Mouse.LeftButton != MouseButtonState.Pressed)
                Cursor = Cursors.Arrow;
        }

        /// <summary>
        /// ResizeRectangle_MouseMove
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ResizeRectangle_MouseMove(object sender, MouseEventArgs e)
        {
            Rectangle rectangle = sender as Rectangle;
            switch (rectangle.Name)
            {
                case "top":
                    Cursor = Cursors.SizeNS;
                    break;

                case "bottom":
                    Cursor = Cursors.SizeNS;
                    break;

                case "left":
                    Cursor = Cursors.SizeWE;
                    break;

                case "right":
                    Cursor = Cursors.SizeWE;
                    break;

                case "topLeft":
                    Cursor = Cursors.SizeNWSE;
                    break;

                case "topRight":
                    Cursor = Cursors.SizeNESW;
                    break;

                case "bottomLeft":
                    Cursor = Cursors.SizeNESW;
                    break;

                case "bottomRight":
                    Cursor = Cursors.SizeNWSE;
                    break;
            }
        }

        /// <summary>
        /// ResizeRectangle_PreviewMouseDown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ResizeRectangle_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            Rectangle rectangle = sender as Rectangle;
            switch (rectangle.Name)
            {
                case "top":
                    Cursor = Cursors.SizeNS;
                    ResizeWindow(ResizeDirection.Top);
                    break;

                case "bottom":
                    Cursor = Cursors.SizeNS;
                    ResizeWindow(ResizeDirection.Bottom);
                    break;

                case "left":
                    Cursor = Cursors.SizeWE;
                    ResizeWindow(ResizeDirection.Left);
                    break;

                case "right":
                    Cursor = Cursors.SizeWE;
                    ResizeWindow(ResizeDirection.Right);
                    break;

                case "topLeft":
                    Cursor = Cursors.SizeNWSE;
                    ResizeWindow(ResizeDirection.TopLeft);
                    break;

                case "topRight":
                    Cursor = Cursors.SizeNESW;
                    ResizeWindow(ResizeDirection.TopRight);
                    break;

                case "bottomLeft":
                    Cursor = Cursors.SizeNESW;
                    ResizeWindow(ResizeDirection.BottomLeft);
                    break;

                case "bottomRight":
                    Cursor = Cursors.SizeNWSE;
                    ResizeWindow(ResizeDirection.BottomRight);
                    break;
            }
        }

        private static IntPtr WindowProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            switch (msg)
            {
                case 0x0024:
                    WmGetMinMaxInfo(hwnd, lParam);
                    handled = true;
                    break;
            }

            return (IntPtr)0;
        }

        private static void WmGetMinMaxInfo(IntPtr hwnd, IntPtr lParam)
        {
            NativeMethods.MINMAXINFO mmi = (NativeMethods.MINMAXINFO)Marshal.PtrToStructure(lParam, typeof(NativeMethods.MINMAXINFO));

            // Adjust the maximized size and position to fit the work area of the correct monitor
            int MONITOR_DEFAULTTONEAREST = 0x00000002;
            IntPtr monitor = NativeMethods.MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST);

            if (monitor != IntPtr.Zero)
            {
                NativeMethods.MONITORINFO monitorInfo = new NativeMethods.MONITORINFO();
                NativeMethods.GetMonitorInfo(monitor, monitorInfo);
                NativeMethods.RECT rcWorkArea = monitorInfo.rcWork;
                NativeMethods.RECT rcMonitorArea = monitorInfo.rcMonitor;
                mmi.ptMaxPosition.x = Math.Abs(rcWorkArea.left - rcMonitorArea.left);
                mmi.ptMaxPosition.y = Math.Abs(rcWorkArea.top - rcMonitorArea.top);
                mmi.ptMaxSize.x = Math.Abs(rcWorkArea.right - rcWorkArea.left);
                mmi.ptMaxSize.y = Math.Abs(rcWorkArea.bottom - rcWorkArea.top);
            }

            Marshal.StructureToPtr(mmi, lParam, true);
        }

        private void BaseWindow_Closing(object sender, CancelEventArgs e)
        {
            Closing -= BaseWindow_Closing;
            e.Cancel = true;
            DoubleAnimation animation = new DoubleAnimation(0, TimeSpan.FromMilliseconds(100));
            animation.Completed += (s, ev) =>
            {
                Close();
            };
            BeginAnimation(OpacityProperty, animation);
        }

        private void BaseWindow_SourceInitialized(object sender, EventArgs e)
        {
            IntPtr handle = (new WindowInteropHelper(this)).Handle;
            HwndSource.FromHwnd(handle).AddHook(WindowProc);
        }

        private Point GetMousePosition()
        {
            System.Drawing.Point point = System.Windows.Forms.Control.MousePosition;
            return new Point(point.X, point.Y);
        }

        private void maximizeButton_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState == WindowState.Normal ? WindowState.Maximized : WindowState.Normal;
        }

        private void minimizeButton_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void OnSourceInitialized(object sender, EventArgs e)
        {
            _hwndSource = (HwndSource)PresentationSource.FromVisual(this);
        }

        private void ResizeWindow(ResizeDirection direction)
        {
            NativeMethods.SendMessage(_hwndSource.Handle, 0x112, (IntPtr)(61440 + direction), IntPtr.Zero);
        }

        private void title_MouseMove(object sender, MouseEventArgs e)
        {
            if (Mouse.LeftButton == MouseButtonState.Pressed)
                if (WindowState == WindowState.Maximized)
                {
                    Point position = PointToScreen(Mouse.GetPosition(this));

                    if (Math.Abs(position.X - _startPoint.X) > SystemParameters.MinimumHorizontalDragDistance ||
                        Math.Abs(position.Y - _startPoint.Y) > SystemParameters.MinimumVerticalDragDistance)
                    {
                        double borderHeight = ((Border)sender).Height;
                        double maxWidth = ((Border)sender).ActualWidth;
                        double rightFromMouse = maxWidth - Mouse.GetPosition((Border)sender).X;
                        var proc = (rightFromMouse * 100) / maxWidth;

                        var transform = PresentationSource.FromVisual(this).CompositionTarget.TransformFromDevice;
                        var mouse = transform.Transform(GetMousePosition());

                        Top = mouse.Y - borderHeight / 2;
                        Left = (mouse.X - RestoreBounds.Width) + ((RestoreBounds.Width * proc) / 100);

                        WindowState = WindowState.Normal;

                        DragMove();
                    }
                }
        }

        #endregion Methods
    }
}