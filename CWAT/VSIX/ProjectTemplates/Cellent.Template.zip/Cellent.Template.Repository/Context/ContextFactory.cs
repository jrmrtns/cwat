﻿using $saferootprojectname$.Domain.Core;
using $safeprojectname$.Core.Interfaces;
using System;

namespace $safeprojectname$.Context
{
    /// <summary>
    ///
    /// </summary>
    /// <seealso cref="$safeprojectname$.Core.Interfaces.IContextFactory" />
    public class ContextFactory : IContextFactory
    {
        /// <summary>
        /// Creates this instance.
        /// </summary>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public BaseContext Create()
        {
            return new CellentContext();
        }
    }
}