﻿using $saferootprojectname$.Domain.Core.Implementations;
using $safeprojectname$.Core.Interfaces;
using $safeprojectname$.Context;
using Microsoft.Practices.Unity;

namespace $safeprojectname$
{
    /// <summary>
    /// Module für $safeprojectname$
    /// </summary>
    public class Module : BaseModule
    {
        #region Public Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="Module"/> class.
        /// </summary>
        /// <param name="container">The container.</param>
        public Module(IUnityContainer container) : base(container)
        { }

        #endregion Public Constructors

        #region Public Methods

        /// <summary>
        /// Initializes this instance.
        /// </summary>
        public override void Initialize()
        {
            base.Initialize();

            Container.RegisterType<IContextFactory, ContextFactory>();
        }

        #endregion Public Methods
    }
}