﻿using $saferootprojectname$.Common.Constants;
using $saferootprojectname$.Common.Events;
using $saferootprojectname$.Domain.Core;
using $saferootprojectname$.Domain.Core.Entities;
using $saferootprojectname$.Domain.Core.Interfaces.Entities;
using $safeprojectname$.Core.Interfaces;
using $safeprojectname$.Context;
using Prism.Events;
using System;
using System.Data.Entity;
using System.Threading.Tasks;

namespace $safeprojectname$.Repositories
{
    /// <summary>
    /// Repository
    /// </summary>
    /// <seealso cref="BaseRepository{IChangeLog, ChangeLogDao}" />
    public class ChangeLogRepository : BaseRepository<IChangeLog, ChangeLogDao>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DomainObjectRepository" /> class.
        /// </summary>
        /// <param name="contextFactory">The context factory.</param>
        /// <param name="mapper">The mapper.</param>
        /// <param name="eventAggregator">The event aggregator.</param>
        public ChangeLogRepository(IContextFactory contextFactory, GenericDaoMapper<IChangeLog, ChangeLogDao> mapper,
            IEventAggregator eventAggregator)
            : base(contextFactory, mapper, eventAggregator)
        { }

        /// <summary>
        /// Saves the or update asynchronous.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns></returns>
        public override async Task<IChangeLog> SaveOrUpdateAsync(IChangeLog entity)
        {
            ChangeLogDao dao = Mapper.Convert(entity);

            dao.ChangedAt = DateTime.Now;
            if (dao.ChangedBy == Guid.Empty)
                dao.ChangedBy = CurrentUserId;

            using (CellentContext context = new CellentContext())
            {
                switch (dao.State)
                {
                    case Constants.EntityState.Created:
                        dao.CreatedAt = DateTime.Now;
                        if (dao.CreatedBy == Guid.Empty)
                            dao.CreatedBy = CurrentUserId;
                        context.Set(dao.GetType()).Add(dao);
                        break;

                    case Constants.EntityState.Modified:
                        context.Set(dao.GetType()).Attach(dao);
                        context.Entry(dao).State = EntityState.Modified;
                        break;
                }

                context.Entry(dao.DomainObject).State = EntityState.Unchanged;
                await context.SaveChangesAsync();

                entity = Mapper.Convert(dao);
                EventAggregator.GetEvent<EntityUpdated>().Publish(entity);

                return entity;
            }
        }
    }
}