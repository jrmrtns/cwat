﻿using $saferootprojectname$.Common.Interceptors;
using $saferootprojectname$.Domain.Core;
using $saferootprojectname$.Domain.Interfaces.Entities;
using $safeprojectname$.Core.Interfaces;
using $safeprojectname$.Context;
using $safeprojectname$.Entities;
using $safeprojectname$.Interfaces.Repositories;
using Prism.Events;
using System.Collections.Generic;
using System.Data.Entity;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.Repositories
{
    /// <summary>
    /// Repository for resources
    /// </summary>
    [Log]
    public class ResourceRepository : BaseRepository<IResource, ResourceDao>, IResourceRepository
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ResourceRepository" /> class.
        /// </summary>
        /// <param name="contextFactory">The context factory.</param>
        /// <param name="mapper">The mapper.</param>
        /// <param name="eventAggregator">The EventAggregator</param>
        public ResourceRepository(IContextFactory contextFactory, GenericDaoMapper<IResource, ResourceDao> mapper, IEventAggregator eventAggregator)
            : base(contextFactory, mapper, eventAggregator)
        { }

        /// <summary>
        /// Finds by culture information.
        /// </summary>
        /// <param name="cultureInfo">The culture information.</param>
        /// <returns></returns>
        [Cache(TypeToMonitor = typeof(IResource))]
        public virtual IEnumerable<IResource> FindForCultureInfo(CultureInfo cultureInfo)
        {
            using (CellentContext context = new CellentContext())
            {
                return Mapper.Convert(context.Resources.Where(d => d.Language == cultureInfo.Name).ToList());
            }
        }

        /// <summary>
        /// Finds all entries paged for culture information.
        /// </summary>
        /// <param name="page">The page.</param>
        /// <param name="pageSize">Size of the page.</param>
        /// <returns></returns>
        public async Task<IEnumerable<IResource>> FindAllPagedAsync(int page, int pageSize)
        {
            using (CellentContext context = new CellentContext())
            {
                return Mapper.Convert(await context.Resources
                    .OrderBy(d => d.Key)
                    .Skip(page * pageSize)
                    .Take(pageSize)
                    .ToListAsync());
            }
        }
    }
}