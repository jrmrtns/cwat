﻿using $saferootprojectname$.Client.Core.Interfaces.Models;
using $saferootprojectname$.Client.Core.ServiceClient;
using $saferootprojectname$.Common.DataTransferObjects;
using $saferootprojectname$.Common.Exceptions;
using $saferootprojectname$.Common.Interfaces.WCFServices;
using $saferootprojectname$.Common.Validation;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace $safeprojectname$.Models
{
    public partial class RoleModel
    {
        /// <summary>
        /// Gets or sets the right groups.
        /// </summary>
        /// <value>
        /// The right groups.
        /// </value>
        public virtual IEnumerable<IRightModel> Rights { get; set; }

        /// <summary>
        /// Marks entity state as modified
        /// </summary>
        public virtual void MarkModified()
        {
            ChangedAt = DateTime.Now;
        }

        /// <summary>
        /// Saves this instance.
        /// </summary>
        /// <returns></returns>
        public async Task<IRoleModel> SaveAsync()
        {
            ValidationSummary summary = Validator.Validate(this);
            if (!summary.IsValid)
                throw new ValidationException(summary);

            RoleDto role = await ServiceClient<IRoleService>.ExecuteAsync(d => d.SaveRoleAsync(Factory.Convert(this)));

            IRoleModel roleModel = Factory.Convert(role);

            return roleModel;
        }
    }
}