﻿using $saferootprojectname$.Client.Core.Interfaces.Models;
using $saferootprojectname$.Client.Core.ServiceClient;
using $saferootprojectname$.Common.DataTransferObjects;
using $saferootprojectname$.Common.Interfaces.Core;
using $saferootprojectname$.Common.Interfaces.WCFServices;
using $saferootprojectname$.Common.Validation;
using $saferootprojectname$.Common.Validation.Validators;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using ValidationException = $saferootprojectname$.Common.Exceptions.ValidationException;
using Validator = $saferootprojectname$.Common.Validation.Validator;

namespace $safeprojectname$.Models
{
    [MetadataType(typeof(UserModelMetadata))]
    partial class UserModel : ICollectionObserver
    {
        #region Properties

        /// <summary>
        /// Gets or sets Roles
        /// </summary>
        [NotNullValidator]
        public virtual IRoleModel Role { get; set; }

        #endregion Properties

        #region Methods

        /// <summary>
        /// Saves this instance.
        /// </summary>
        /// <returns></returns>
        public async Task<IUserModel> SaveAsync()
        {
            ValidationSummary summary = Validator.Validate(this);
            if (!summary.IsValid)
                throw new ValidationException(summary);

            UserDto user = await ServiceClient<IUserService>.ExecuteAsync(d => d.SaveUserAsync(Factory.Convert(this)));

            return Factory.Convert(user);
        }

        #endregion Methods
    }
}