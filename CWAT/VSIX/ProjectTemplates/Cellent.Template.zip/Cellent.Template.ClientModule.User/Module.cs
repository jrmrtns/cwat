﻿using $saferootprojectname$.Client.Core.Core;
using $safeprojectname$.ViewModels;
using $safeprojectname$.Views;
using $saferootprojectname$.Common.Constants;
using $saferootprojectname$.Common.Interceptors;
using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.InterceptionExtension;
using Prism.Modularity;
using System.ComponentModel;
using System.Diagnostics;
using CreateUserView = $safeprojectname$.Views.CreateUserView;

namespace $safeprojectname$
{
    /// <summary>
    /// Beschreibt das UserModule
    /// </summary>
    [Module(ModuleName = Constants.Modules.UserModule)]
    public class Module : BaseModule
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Module"/> class.
        /// </summary>
        /// <param name="container">The container.</param>
        public Module(IUnityContainer container) : base(container)
        {
        }

        /// <summary>
        /// Notifies the module that it has be initialized.
        /// </summary>
        public override void Initialize()
        {
            base.Initialize();

            Container.RegisterType<object, CreateUserView>(Constants.ViewNames.CreateUserView);
            Container.RegisterType<object, UserList>(Constants.ViewNames.ListUser);

            Container.RegisterType<CreateUserViewModel>(
                new Interceptor<VirtualMethodInterceptor>(),
                new InterceptionBehavior(new LoggingBehavior(TraceEventType.Verbose)),
                new AdditionalInterface<INotifyPropertyChanged>(),
                new InterceptionBehavior<NotifyPropertyChangedBehavior>());

            Container.RegisterType<UserListViewModel>(
                new Interceptor<VirtualMethodInterceptor>(),
                new InterceptionBehavior(new LoggingBehavior(TraceEventType.Verbose)),
                new AdditionalInterface<INotifyPropertyChanged>(),
                new InterceptionBehavior<NotifyPropertyChangedBehavior>());
        }
    }
}