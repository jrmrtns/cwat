﻿using $safeprojectname$;

namespace $saferootprojectname$.Repository.Core.Interfaces
{
    public interface IContextFactory
    {
        BaseContext Create();
    }
}