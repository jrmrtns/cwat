﻿using System;

namespace $safeprojectname$.Interceptors
{
    /// <summary>
    /// Handelt die Datenbankaktionen in einer Transaction ab
    /// </summary>
    /// <seealso cref="System.Attribute" />
    public class TransactionAttribute : Attribute
    { }
}