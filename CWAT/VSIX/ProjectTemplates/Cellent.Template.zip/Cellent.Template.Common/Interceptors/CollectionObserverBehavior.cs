﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using $safeprojectname$.Interceptors.Helper;
using $safeprojectname$.Interfaces.Core;
using Microsoft.Practices.Unity.InterceptionExtension;

namespace $safeprojectname$.Interceptors
{
    /// <summary>
    /// Aspect zur Validierung über zusätzliches Interface
    /// </summary>
    public class CollectionObserverBehavior : IInterceptionBehavior
    {
        private IBaseModel _baseModel;

        /// <summary>
        /// Implement this method to execute your behavior processing.
        /// </summary>
        /// <param name="input">Inputs to the current call to the target.</param>
        /// <param name="getNext">Delegate to execute to get the next delegate in the behavior chain.</param>
        /// <returns>
        /// Return value from the target.
        /// </returns>
        public IMethodReturn Invoke(IMethodInvocation input, GetNextInterceptionBehaviorDelegate getNext)
        {
            if (input.Target is ICollectionObserver && input.MethodBase.Name.StartsWith("set_"))
                if (IsObservableCollection(input.Arguments[0]))
                {
                    _baseModel = input.Target as IBaseModel;
                    EventInfo eventInfo = input.Arguments[0].GetType().GetEvent("CollectionChanged");
                    Type delegateType = eventInfo.EventHandlerType;

                    MethodInfo miHandler = GetType().GetMethod("CollectionChanged", BindingFlags.NonPublic | BindingFlags.Instance);
                    Delegate handler = Delegate.CreateDelegate(delegateType, this, miHandler);

                    eventInfo.AddEventHandler(input.Arguments[0], handler);
                }

            return getNext()(input, getNext);
        }

        private static bool IsObservableCollection(object input)
        {
            return input != null 
                && input.GetType().IsGenericType 
                && input.GetType().GetGenericTypeDefinition() == typeof (ObservableCollection<>);
        }

        // ReSharper disable once UnusedMember.Local
        private void CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            Constants.Constants.EntityState objectState = (Constants.Constants.EntityState)_baseModel.GetType().GetProperty("State").GetValue(_baseModel);
            if (objectState == Constants.Constants.EntityState.Unchanged)
                _baseModel.GetType().GetProperty("State").SetValue(_baseModel, Constants.Constants.EntityState.Modified);

            PropertyInfo propertyInfo = _baseModel.GetType()
                .GetProperties()
                .FirstOrDefault(d => d.GetValue(_baseModel) == sender);

            if (propertyInfo == null)
            {
                Logger.Logger.Write("Could not resolve property. Cannot write change to ChangeLog", TraceEventType.Warning);
                return;
            }

            // ReSharper disable once SuspiciousTypeConversion.Global
            IUnitOfWork unitOfWork = _baseModel as IUnitOfWork;
            if (unitOfWork != null)
                unitOfWork.AddChange(new UnitOfWorkItem
                {
                    PropertyName = propertyInfo.Name,
                    NewValue = e.Action.ToString(),
                    TimeStamp = DateTime.Now
                });
        }

        /// <summary>
        /// Returns the interfaces required by the behavior for the objects it intercepts.
        /// </summary>
        /// <returns>
        /// The required interfaces.
        /// </returns>
        public IEnumerable<Type> GetRequiredInterfaces()
        {
            return new[] { typeof(IBaseModel) };
        }

        /// <summary>
        /// Returns a flag indicating if this behavior will actually do anything when invoked.
        /// </summary>
        /// <remarks>
        /// This is used to optimize interception. If the behaviors won't actually
        /// do anything (for example, PIAB where no policies match) then the interception
        /// mechanism can be skipped completely.
        /// </remarks>
        public bool WillExecute { get { return true; } }

    }
}
