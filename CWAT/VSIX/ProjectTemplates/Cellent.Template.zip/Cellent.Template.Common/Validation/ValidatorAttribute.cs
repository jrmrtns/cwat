using System;
using $safeprojectname$.Validation.Validators;

namespace $safeprojectname$.Validation
{
    /// <summary>
    /// ValidatorAttribute
    /// </summary>
    public abstract class ValidatorAttribute : AbstractValidator
    {
        internal abstract String Message
        {
            get;
            set;
        }
    }
}
