﻿using $safeprojectname$.Validation;

namespace $safeprojectname$.Interfaces.Core
{
    /// <summary>
    /// Zusätzliches Interface für Interception
    /// </summary>
    public interface IValidatable
    {
        /// <summary>
        /// Determines whether this instance is valid.
        /// </summary>
        /// <returns></returns>
        ValidationSummary Validate();
    }
}
