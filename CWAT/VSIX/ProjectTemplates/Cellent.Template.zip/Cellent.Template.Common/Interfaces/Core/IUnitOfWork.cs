﻿using System.Collections.Generic;
using $safeprojectname$.Interceptors.Helper;

namespace $safeprojectname$.Interfaces.Core
{
    /// <summary>
    /// Interface für UnitOfWork Implementation
    /// </summary>
    public interface IUnitOfWork
    {
        /// <summary>
        /// Gets the changes.
        /// </summary>
        /// <value>
        /// The changes.
        /// </value>
        IEnumerable<UnitOfWorkItem> ChangeLog { get; set; }

        /// <summary>
        /// Adds the change.
        /// </summary>
        /// <param name="unitOfWorkItem">The unit of work item.</param>
        void AddChange(UnitOfWorkItem unitOfWorkItem);
    }
}
