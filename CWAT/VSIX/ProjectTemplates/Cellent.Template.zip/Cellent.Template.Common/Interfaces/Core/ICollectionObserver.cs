﻿namespace $safeprojectname$.Interfaces.Core
{
    /// <summary>
    /// Überwacht Änderungen an Observable Collections in übergeordneten Objekten
    /// </summary>
    public interface ICollectionObserver
    {
    }
}
