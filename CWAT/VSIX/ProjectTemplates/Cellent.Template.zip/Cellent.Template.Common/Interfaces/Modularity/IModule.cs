﻿namespace $safeprojectname$.Interfaces.Modularity
{
    /// <summary>
    /// Modularity
    /// </summary>
    public interface IModule
    {
        /// <summary>
        /// Initializes this instance.
        /// </summary>
        void Initialize();
    }
}
