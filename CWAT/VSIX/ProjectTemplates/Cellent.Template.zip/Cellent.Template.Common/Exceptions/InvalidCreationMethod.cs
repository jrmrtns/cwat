﻿using System;

namespace $safeprojectname$.Exceptions
{
    /// <summary>
    /// Wird geworfen wenn ein Model nicht über die Factories erzeugt wurde
    /// </summary>
    [Serializable]
    public class InvalidCreationMethod : Exception
    {
    }
}
