﻿using $saferootprojectname$.Domain.Interfaces.Entities;
using $saferootprojectname$.Repository.Interfaces.Repositories;
using System.Collections.Generic;
using System.Globalization;
using System.Threading.Tasks;

namespace $safeprojectname$.Entities
{
    public partial class Resource
    {
        public async Task<bool> DeleteAsync(IResource resource)
        {
            return await Repository.DeleteAsync(resource);
        }

        public IEnumerable<IResource> FindForCultureInfo(CultureInfo cultureInfo)
        {
            return ((IResourceRepository)Repository).FindForCultureInfo(cultureInfo);
        }

        public async Task<IEnumerable<IResource>> FindAllAsync()
        {
            return await ((IResourceRepository)Repository).FindAllAsync();
        }
    }
}