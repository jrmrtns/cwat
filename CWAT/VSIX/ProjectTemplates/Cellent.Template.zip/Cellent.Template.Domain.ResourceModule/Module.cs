﻿using $saferootprojectname$.Domain.Core.Implementations;
using Microsoft.Practices.Unity;

namespace $safeprojectname$
{
    /// <summary>
    /// UserModule
    /// </summary>
    public class Module: BaseModule
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Module"/> class.
        /// </summary>
        /// <param name="container">The container.</param>
        public Module(IUnityContainer container) : base(container)
        { }
    }
}
