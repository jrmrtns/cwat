﻿using $saferootprojectname$.Domain.Core;
using $saferootprojectname$.Domain.Core.Interfaces.Factories;
using $saferootprojectname$.Domain.Interfaces.Entities;
using $saferootprojectname$.Repository.Entities;
using System;
using System.Linq;

namespace $safeprojectname$.DaoMapper
{
    public partial class RoleMapper
    {
        private readonly GenericDaoMapper<IRight, RightDao> _rightMapper;

        /// <summary>
        /// RoleMapper
        /// </summary>
        /// <param name="factory"></param>
        /// <param name="rightMapper"></param>
        public RoleMapper(Lazy<IDomainFactory<IRole>> factory, GenericDaoMapper<IRight, RightDao> rightMapper)
            : this(factory)
        {
            _rightMapper = rightMapper;
        }

        partial void OnConvertAdditionalFields(RoleDao source, IRole dest)
        {
            if (source.Rights != null)
                dest.Rights = _rightMapper.Convert(source.Rights);
        }

        partial void OnConvertAdditionalFields(IRole source, RoleDao dest)
        {
            if (source.Rights != null)
                dest.Rights = _rightMapper.Convert(source.Rights).ToList();
        }
    }
}